# Placeholder README (will be updated by resubmission script)
## ✅ Resubmission Notes
- Added baseline vs LLM comparison and threshold rationale
- Explanations after each chart
- R² and MAE with commentary
- Error analysis, limitations, ethics & reproducibility
